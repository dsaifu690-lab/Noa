package com.jarvisnova

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var statusView: TextView
    private lateinit var conversationView: TextView
    private lateinit var messageInput: EditText
    private lateinit var speakButton: Button
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("jarvis_nova", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        renderScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        }
        statusView.text = "SYSTEM ONLINE • Tap Speak to talk"
    }

    private fun renderScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 18)
            setBackgroundColor(Color.rgb(10, 13, 19))
        }

        val logo = TextView(this).apply {
            text = "J A R V I S   N O V A"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(0, 235, 200))
            setPadding(0, 10, 0, 4)
        }
        val sub = TextView(this).apply {
            text = "PERSONAL VOICE INTELLIGENCE"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(145, 160, 177))
            setPadding(0, 0, 0, 20)
        }
        statusView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(0, 235, 200))
            setPadding(0, 8, 0, 12)
        }
        conversationView = TextView(this).apply {
            text = "Hello! I'm Jarvis Nova.\n\nTap Speak and ask me something."
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 12)
        }
        val scroll = ScrollView(this).apply {
            addView(conversationView)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        messageInput = EditText(this).apply {
            hint = "Type a message…"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(28, 34, 44))
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) {
                    submitTypedMessage()
                    true
                } else false
            }
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        speakButton = Button(this).apply {
            text = "🎙  Speak"
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { listen() }
        }
        val send = Button(this).apply {
            text = "Send"
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { submitTypedMessage() }
        }
        controls.addView(speakButton)
        controls.addView(send)

        val apiSettings = Button(this).apply {
            text = "Gemini API Key"
            setOnClickListener { editApiKey() }
        }
        root.addView(logo)
        root.addView(sub)
        root.addView(statusView)
        root.addView(scroll)
        root.addView(messageInput)
        root.addView(controls)
        root.addView(apiSettings)
        setContentView(root)
    }

    private fun submitTypedMessage() {
        val text = messageInput.text.toString().trim()
        if (text.isNotEmpty()) {
            messageInput.text.clear()
            handleCommand(text)
        }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusView.text = "Speech recognition isn't available."
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { statusView.text = "LISTENING • Speak now" }
                override fun onBeginningOfSpeech() { statusView.text = "HEARING YOU…" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { statusView.text = "PROCESSING…" }
                override fun onError(error: Int) {
                    statusView.text = "Didn't catch that. Tap Speak to retry."
                    speakButton.text = "🎙  Speak"
                }
                override fun onResults(results: Bundle?) {
                    speakButton.text = "🎙  Speak"
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!phrase.isNullOrBlank()) handleCommand(phrase)
                    else statusView.text = "No speech detected."
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Jarvis Nova")
            }
            speakButton.text = "Listening…"
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            statusView.text = "Unable to start speech recognition."
            speakButton.text = "🎙  Speak"
        }
    }

    private fun handleCommand(raw: String) {
        val q = raw.trim()
        if (q.isEmpty()) return
        addMessage("YOU", q)
        val lower = q.lowercase(Locale.ROOT)
        when {
            lower.contains("what time") || lower == "time" || lower.contains("current time") -> {
                say("It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            }
            lower.startsWith("open youtube") -> openApp("com.google.android.youtube", "YouTube")
            lower.startsWith("open chrome") -> openApp("com.android.chrome", "Chrome")
            lower.startsWith("open maps") || lower.startsWith("open google maps") -> openApp("com.google.android.apps.maps", "Maps")
            lower.startsWith("open camera") -> {
                try {
                    startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                    say("Opening Camera.")
                } catch (_: Exception) { say("I couldn't open the camera.") }
            }
            lower.startsWith("open settings") -> {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                    say("Opening Settings.")
                } catch (_: Exception) { say("I couldn't open Settings.") }
            }
            else -> askGemini(q)
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            say("Opening $label.")
        } else say("$label doesn't seem to be installed.")
    }

    private fun askGemini(question: String) {
        val key = prefs.getString("gemini_key", "")?.trim().orEmpty()
        if (key.isBlank()) {
            say("Add your Gemini API key using the button below to enable AI answers.")
            return
        }
        statusView.text = "THINKING…"
        worker.execute {
            var connection: HttpURLConnection? = null
            try {
                val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + Uri.encode(key)
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }
                val request = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "You are Jarvis Nova, a helpful, friendly Android voice assistant. Keep spoken answers concise."))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", question)))))
                connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw Exception("Gemini request failed (HTTP $code). Check your API key/model access.")
                val answer = JSONObject(response).optJSONArray("candidates")
                    ?.optJSONObject(0)?.optJSONObject("content")
                    ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                    ?.takeIf { !it.isNullOrBlank() } ?: "I couldn't generate a response."
                runOnUiThread { say(answer) }
            } catch (e: Exception) {
                runOnUiThread { say("AI request failed. Check your internet connection and Gemini API key. ${e.message ?: ""}") }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun editApiKey() {
        val field = EditText(this).apply {
            hint = "Paste Gemini API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("gemini_key", ""))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Gemini API key")
            .setMessage("Stored locally on this phone. Do not commit API keys to GitHub.")
            .setView(field)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_key", field.text.toString().trim()).apply()
                statusView.text = "API KEY SAVED"
                Toast.makeText(this, "API key saved on device", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Clear") { _, _ ->
                prefs.edit().remove("gemini_key").apply()
                statusView.text = "API KEY CLEARED"
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addMessage(who: String, text: String) {
        conversationView.text = "${conversationView.text}\n\n$who: $text".trim()
    }

    private fun say(text: String) {
        statusView.text = "SYSTEM ONLINE"
        addMessage("JARVIS", text)
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_nova_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            statusView.text = "MICROPHONE READY • Tap Speak"
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }
}
