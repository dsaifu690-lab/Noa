# Jarvis Nova — Android Voice Assistant

A clean, new Android project with GitHub Actions to build a debug APK automatically.

## What it does
- Push-to-talk voice input with Android SpeechRecognizer.
- Spoken answers using Android Text-to-Speech.
- Gemini AI chat using an API key entered inside the app.
- Basic voice commands: open YouTube, Chrome, Maps, Camera, Settings, and tell the time.
- Dark sci-fi interface.
- GitHub Actions builds and uploads `app-debug.apk`.

## Build from GitHub on your phone
1. Create a new GitHub repository called `JarvisNova`.
2. Upload the contents of this folder to the repository root (not the ZIP file).
3. Ensure the hidden path `.github/workflows/android.yml` is included.
4. Open Actions → **Build Jarvis Nova APK**. If it didn't start automatically, tap **Run workflow**.
5. Download the `jarvis-nova-debug-apk` artifact from the successful run and extract `app-debug.apk`.

## Gemini API key
Create a Gemini API key through Google AI Studio. Install the app, tap **Gemini API Key**, and paste it there. The key is saved only in the app's local preferences. Never put API keys in the GitHub source.

This is a starter app, not an always-on wake-word listener. The microphone starts only when you tap the Speak button. True "Hey Jarvis" support needs a wake-word engine and a foreground microphone service, subject to Android background restrictions.

## Requirements
- Android SDK compile API 35 (provided by GitHub Actions environment through Gradle build setup)
- Java 17
- Android Gradle Plugin 8.7.3 / Gradle 8.9
